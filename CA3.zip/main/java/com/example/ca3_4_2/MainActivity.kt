package com.example.ca3_4_2

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var proximitySensor: Sensor? = null

    private lateinit var tv:TextView
    private lateinit var iv:ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tv = findViewById(R.id.text_view)
        iv= findViewById(R.id.image_view)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)

    }

    override fun onSensorChanged(event: SensorEvent?) {
        if(event?.sensor?.type == Sensor.TYPE_PROXIMITY) {
            when(event.values[0]) {
               in 0.0..3.0 -> {
                   tv.text = event.values[0].toString()

               }
                in 3.1..7.0 -> {
                    tv.text = event.values[0].toString()
                    tv.alpha = 0.5f
                    iv.setImageResource(R.drawable.second)
                }
                 in 7.1..10.0 -> {
                    tv.text = event.values[0].toString()
                    tv.alpha = 1.0f
                    iv.setImageResource(R.drawable.third)
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        return
    }

    override fun onResume() {
        super.onResume()
        sensorManager.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }
}



