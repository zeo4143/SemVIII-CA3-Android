package com.example.ca1_semviii

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.ca1_semviii.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {


    private lateinit var viewBinding: ActivityMainBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //Firebase Initialisation
        firebaseAuth = FirebaseAuth.getInstance()

        viewBinding.LogIn.setOnClickListener {
            signInWithEmailAndPassword(viewBinding.LogInEmail.text.toString(), viewBinding.LogInPassword.text.toString())
        }

    }

    private fun signInWithEmailAndPassword(email:String, password:String) {
        firebaseAuth.signInWithEmailAndPassword(email,password).addOnSuccessListener {
            Toast.makeText(this, "Successfully Logged In", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, HomePage::class.java))
        }.addOnFailureListener {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show()
            viewBinding.LogInEmail.text.clear()
            viewBinding.LogInPassword.text.clear()
        }
    }
}