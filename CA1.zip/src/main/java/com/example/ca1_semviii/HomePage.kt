package com.example.ca1_semviii

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ca1_semviii.databinding.ActivityHomePageBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class HomePage : AppCompatActivity() {

    private lateinit var viewBinding: ActivityHomePageBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityHomePageBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        firebaseDatabase = FirebaseDatabase.getInstance()


        recyclerView = viewBinding.studentsListRecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        checkCurrentUser()

        viewBinding.logOut.setOnClickListener{
            firebaseAuth.signOut()
            checkCurrentUser()
        }

        viewBinding.addStudent.setOnClickListener {
            addData(viewBinding.enterRegNo.text.toString().toLong(), viewBinding.enterStream.text.toString(),viewBinding.enterQualification.text.toString())
        }
    }

    private fun checkCurrentUser() {
        if(firebaseAuth.currentUser != null) {
            fetchData()

        } else {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun addData(regNo: Long, stream: String, qualification: String) {
        firebaseDatabase.reference.child("students").child(regNo.toString()).setValue(Student(regNo,stream,qualification)).addOnSuccessListener {
            Toast.makeText(this, "Data Added", Toast.LENGTH_SHORT).show()
            viewBinding.enterRegNo.text.clear()
            viewBinding.enterStream.text.clear()
            viewBinding.enterQualification.text.clear()
        }.addOnFailureListener {
            Toast.makeText(this, "Something Went Wrong", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchData() {
        viewBinding.progressBar.visibility = View.VISIBLE
        val list = mutableListOf<Student>()

        firebaseDatabase.getReference("students").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                if(snapshot.exists()) {
                    for(student in snapshot.children.reversed()) {
                        var data = student.getValue(Student::class.java)!!
                        list.add(data)
                    }

                    viewBinding.progressBar.visibility = View.GONE
                    val adapter = DisplayStudentsAdapter(list)
                    recyclerView.adapter = adapter

                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext, "something Went Wrong", Toast.LENGTH_SHORT).show()
            }

        })
    }
}