package com.example.ca1_semviii

data class Student(
    val regNo: Long? = null,
    val stream:String? = null,
    val lastQualification:String? = null
)
