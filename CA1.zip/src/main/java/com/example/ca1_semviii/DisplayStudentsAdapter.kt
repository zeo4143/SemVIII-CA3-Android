package com.example.ca1_semviii

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DisplayStudentsAdapter(private val studentList: List<Student>) :
    RecyclerView.Adapter<DisplayStudentsAdapter.StudentViewHolder>() {

    inner class StudentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var regNoTextView: TextView = itemView.findViewById(R.id.student_regNo)
        var streamTextView: TextView = itemView.findViewById(R.id.student_stream)
        var lastQualificationTextView: TextView = itemView.findViewById(R.id.student_qualification)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.students_adapter, parent, false)
        return StudentViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        val currentStudent = studentList[position]
        holder.regNoTextView.text = currentStudent.regNo.toString()
        holder.streamTextView.text = currentStudent.stream
        holder.lastQualificationTextView.text = currentStudent.lastQualification
    }

    override fun getItemCount(): Int {
        return studentList.size
    }
}